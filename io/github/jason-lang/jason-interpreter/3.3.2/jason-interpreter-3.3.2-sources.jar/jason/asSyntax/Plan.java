package jason.asSyntax;

import java.io.Serializable;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import jason.pl.PlanLibrary;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import jason.JasonException;
import jason.asSemantics.Unifier;
import jason.asSyntax.PlanBody.BodyType;
import jason.asSyntax.parser.as2j;

/** Represents an AgentSpeak plan
    (it extends structure to be used as a term)

 @navassoc - label - Pred
 @navassoc - event - Trigger
 @navassoc - context - LogicalFormula
 @navassoc - body - PlanBody
 @navassoc - source - SourceInfo

 */
public class Plan extends Structure implements Cloneable, Serializable {

    private static final long serialVersionUID = 1L;
    private static final Term TAtomic         = ASSyntax.createAtom("atomic");
    private static final Term TBreakPoint     = ASSyntax.createAtom("breakpoint");
    private static final Term TAllUnifs       = ASSyntax.createAtom("all_unifs");

    private static Logger     logger          = Logger.getLogger(Plan.class.getName());

    private Pred              label  = null;
    private Trigger           tevent = null;
    private LogicalFormula    context;
    private PlanBody          body;

    // new in JasonER
    private LogicalFormula    goalCondition;
    private PlanLibrary subplans;
    private PlanLibrary       scope;

    private boolean isAtomic      = false;
    private boolean isAllUnifs    = false;
    private boolean hasBreakpoint = false;

    private boolean     isTerm = false; // it is true when the plan body is used as a term instead of an element of a plan

    private String source = ""; // the source of this plan (file, url, ....)

    // used by clone
    public Plan() {
        super("plan", 0);
    }

    // used by parser
    public Plan(Pred label, Trigger te, LogicalFormula ct, PlanBody bd) {
        super("plan", 0);
        tevent = te;
        tevent.setAsTriggerTerm(false);
        setLabel(label);
        setContext(ct);
        if (bd == null) {
            body = new PlanBodyImpl();
        } else {
            body = bd;
            body.setAsBodyTerm(false);
        }
    }

    @Override
    public int getArity() {
        return 4;
    }

    public void setSourceFile(String f) {
        if (f!=null) {
            this.source = f;
        }
    }
    public String getSourceFile() {
        return this.source;
    }

    @Deprecated public String getFile()       { return this.source; }

    private static final Term noLabelAtom = new Atom("nolabel");

    @Override
    public Term getTerm(int i) {
        switch (i) {
        case 0:
            return (label == null) ? noLabelAtom : label;
        case 1:
            return tevent;
        case 2:
            return (context == null) ? Literal.LTrue : context;
        case 3:
            if (body.getBodyNext() == null && body.getBodyTerm() != null && body.getBodyType() == BodyType.none && body.getBodyTerm().isVar()) // the case of body as a single var
                return body.getBodyTerm();
            return body;
        default:
            return null;
        }
    }

    @Override
    public void setTerm(int i, Term t) {
        switch (i) {
        case 0:
            label   = (Pred)t;
            break;
        case 1:
            tevent  = (Trigger)t;
            break;
        case 2:
            context = (LogicalFormula)t;
            break;
        case 3:
            body    = (PlanBody)t;
            break;
        }
    }

    public void setLabel(Pred p) {
        label = p;
        isAtomic      = false;
        hasBreakpoint = false;
        isAllUnifs    = false;
        if (p != null && p.hasAnnot()) {
            for (Term t: label.getAnnots()) {
                if (t.equals(TAtomic))
                    isAtomic = true;
                if (t.equals(TBreakPoint))
                    hasBreakpoint = true;
                if (t.equals(TAllUnifs))
                    isAllUnifs = true;
                // if change here, also change the clone()!
            }
        }
    }

    public Pred getLabel() {
        return label;
    }

    public void delLabel() {
        setLabel(null);
    }

    public void setContext(LogicalFormula le) {
        context = le;
        if (Literal.LTrue.equals(le))
            context = null;
    }

    public void setAsPlanTerm(boolean b) {
        isTerm = b;
    }

    public boolean isPlanTerm() {
        return isTerm;
    }

    @Override
    public ListTerm getAsListOfTerms() {
        ListTerm l = new ListTermImpl();
        l.add(getLabel());
        l.add(getTrigger());
        l.add(getContext() == null ? Literal.LTrue : getContext());
        l.add(getBody());
        return l;
    }

    @Override
    public List<Term> getTerms() {
        return getAsListOfTerms().getAsList();
    }

    /** creates a plan from a list with four elements: [L, T, C, B] */
    public static Plan newFromListOfTerms(ListTerm lt) throws JasonException {
        Term c = lt.get(2);
        if (c.isPlanBody()) {
            c = ((PlanBody)c).getBodyTerm();
        }
        return new Plan( new Pred((Literal)(lt.get(0))),
                (Trigger)lt.get(1),
                (LogicalFormula)c,
                (PlanBody)lt.get(3));
    }


    /** prefer using ASSyntax.parsePlan */
    public static Plan parse(String sPlan) {
        as2j parser = new as2j(new StringReader(sPlan));
        try {
            return parser.plan();
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error parsing plan " + sPlan, e);
            return null;
        }
    }

    /** @deprecated use getTrigger */
    @Deprecated
    public Trigger getTriggerEvent() {
        return tevent;
    }

    public Trigger getTrigger() {
        return tevent;
    }

    public LogicalFormula getContext() {
        return context;
    }

    public PlanBody getBody() {
        return body;
    }

    public boolean isAtomic() {
        return isAtomic;
    }

    public boolean hasBreakpoint() {
        return hasBreakpoint;
    }

    public boolean isAllUnifs() {
        return isAllUnifs;
    }

    /** returns an unifier if this plan is relevant for the event <i>te</i>,
        returns null otherwise.
    */
    public Unifier isRelevant(Trigger te, Unifier u) {
        // annots in plan's TE must be a subset of the ones in the event!
        // (see definition of Unifier.unifies for 2 Preds)
        if (u == null)
            u = new Unifier();
        if (u.unifiesNoUndo(tevent, te))
            return u;
        else
            return null;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) return true;

        if (o != null && o instanceof Plan p) {
            if (context == null && p.context != null) return false;
            if (context != null && p.context != null && !context.equals(p.context)) return false;
            return tevent.equals(p.tevent) && body.equals(p.body);
        }
        return false;
    }

    public Plan capply(Unifier u) {
        Plan p = new Plan();
        if (label != null) {
            p.label         = (Pred) label.capply(u);
            p.isAtomic      = isAtomic;
            p.hasBreakpoint = hasBreakpoint;
            p.isAllUnifs    = isAllUnifs;
        }

        p.tevent = tevent.capply(u);
        if (context != null)
            p.context = (LogicalFormula)context.capply(u);
        p.body = (PlanBody)body.capply(u);
        p.setSrcInfo(srcInfo);
        p.isTerm = isTerm;

        return p;
    }

    public Term clone() {
        Plan p = new Plan();

        if (label != null)
            p.setLabel((Pred) label.clone());

        p.tevent = tevent.clone();
        if (context != null)
            p.context = (LogicalFormula)context.clone();
        p.body = body.clonePB();
        p.setSrcInfo(srcInfo);
        p.isTerm = isTerm;
        p.source = source;

        if (this.goalCondition != null)
            p.goalCondition = (LogicalFormula)this.goalCondition.clone();
        p.subplans      = this.subplans;
        p.scope         = this.scope;

        return p;
    }

    @Override
    public Plan cloneNS(Atom ns) {
        // TODO: should we change the namespace of all elements of the plan?
        return (Plan)clone();
    }

    /** used to create a plan clone in a new IM */
    public Plan cloneOnlyBody() {
        Plan p = new Plan();
        if (label != null) {
            p.label         = label;
            p.isAtomic      = isAtomic;
            p.hasBreakpoint = hasBreakpoint;
            p.isAllUnifs    = isAllUnifs;
        }

        p.tevent  = tevent.clone();
        p.context = context;
        p.body    = body.clonePB();
        p.scope   = this.scope;

        p.setSrcInfo(srcInfo);
        p.isTerm = isTerm;

        return p;
    }

    public String toString() {
        return toASString();
    }

    /** returns this plan in a string complaint with AS syntax */
    public String toASString() {
        StringBuilder out = new StringBuilder();
        if (isTerm)
            out.append("{ ");
        out.append(((label == null) ? "" : "@" + label + " "));
        out.append(tevent);
        out.append(((context == null) ? "" : " : " + context));
        out.append(((goalCondition == null) ? "" : " <: " + goalCondition));
        if (subplans == null) {
            if (!body.isEmptyBody())
                out.append(" <- " + body);
            if (isTerm)
                out.append(" }");
            else
                out.append(".");
        } else {
            out.append(" {");
            if (!body.isEmptyBody())
                out.append("\n   <- " + body + ".");
            for (Plan p: subplans)
                out.append("\n   "+p.toASString());
            out.append("\n}");
            if (isTerm)
                out.append(" }");
        }
        return out.toString();
    }

    /** get as XML */
    public Element getAsDOM(Document document) {
        Element u = (Element) document.createElement("plan");
        if (label != null) {
            Element l = (Element) document.createElement("label");
            l.appendChild(new LiteralImpl(label).getAsDOM(document));
            u.appendChild(l);
        }
        if (source != null && !source.isEmpty()) {
            u.setAttribute("file", source);
        }

        u.appendChild(tevent.getAsDOM(document));

        if (context != null) {
            Element ec = (Element) document.createElement("context");
            ec.appendChild(context.getAsDOM(document));
            u.appendChild(ec);
        }

        if (!body.isEmptyBody()) {
            u.appendChild(body.getAsDOM(document));
        }

        return u;
    }

    public void addSubPlan(Plan p) throws JasonException {
        if (subplans == null)
            subplans = new PlanLibrary(scope);
        subplans.add(p);
    }
    public boolean hasSubPlans() {
        return subplans != null;
    }
    public boolean hasInterestInUpdateEvents() {
        return subplans != null && subplans.hasPlansForUpdateEvents();
    }
    public PlanLibrary getSubPlans() {
        return subplans;
    }
    public void setScope(PlanLibrary pl) {
        scope = pl;
        if (subplans != null)
            subplans.setFather(scope);
    }
    public PlanLibrary getScope() {
        return scope;
    }

    public void setGoalCondition(LogicalFormula f) {
        goalCondition = f;
    }

    public LogicalFormula getGoalCondition() {
        return goalCondition;
    }
    public boolean hasGoalCondition() {
        return goalCondition != null;
    }
    
    @Override
    public boolean hasSource() {
        return getLabel().hasSource();
    }
    @Override
    public boolean hasSource(Term agName) {
        return getLabel().hasSource(agName);
    }
    
    @Override
    public ListTerm getSources() {
        return getLabel().getSources();
    }
    
    @Override
    public Literal addSource(Term agName) {
        getLabel().addSource(agName);
        return this;
    }
    
    @Override
    public boolean delSource(Term agName) {
        return getLabel().delSource(agName);
    }

    @Override
    public void delSources() {
        getLabel().delSources();
    }

}
